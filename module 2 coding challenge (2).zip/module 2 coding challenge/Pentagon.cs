﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace module_2_coding_challenge
{
    class Pentagon : Polygon
    {
        //attr
        public float Size { get; set; }

        public Pentagon(float size)
        {
            Size = size;
            NumberOfSides = 5;
        }
    }
}
