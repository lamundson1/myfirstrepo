﻿using module_2_coding_challenge;

//create new polygon/square object
Polygon polygon = new Polygon(3);
Square square = new Square(4.5f);
Pentagon pentagon = new Pentagon(5);

//create
player player = new player("frankie", 1);
player.AddPoints(100);

Console.WriteLine("welcome to the game! your score is " + player.GetScore() +
    " you have " + player.GetLivesLeft() + " lives left!");

//kill
player.Kill();

//dead message
Console.WriteLine("An orc attacks you. Sorry, you were killed. you have " + 
    player.GetLivesLeft() + " lives left!");